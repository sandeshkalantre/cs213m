The only difference between using vector and list for the p2 was pushing an element at the front took O(n) time as compared to the list implementation.
