For the first problem, I have used the heurestic as half of the hamming distance between the two strings since it seemed plausible to expect that many swaps.

For the second problem, as a first try I used h  = 0 as heurestic.
