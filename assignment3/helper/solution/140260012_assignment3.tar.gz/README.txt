Bit level hacks
https://graphics.stanford.edu/~seander/bithacks.html
