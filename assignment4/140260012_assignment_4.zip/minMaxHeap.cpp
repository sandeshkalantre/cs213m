#include "minMaxHeap.hpp"

template <class T>
minMaxHeap<T>::minMaxHeap()
{
    vector<T> nodes;
}

template <class T>
void minMaxHeap<T>::insert(T elem)
{
    if(nodes.empty())
    {
        nodes.push_back(elem);
        return;
    }
    else
    {
        nodes.push_back(elem);
        int elem_key = nodes.size() - 1;
        int parent_key = parent(elem_key);
        if(is_min_level(elem_key))
        {
            //inserted position on a min level
            if(nodes[parent_key] < nodes[elem_key])
            {
                // max level violation
                swap_nodes(parent_key,elem_key);
                bubble_up_max(parent_key);
            }
            else
            {
                // min level violation
                bubble_up_min(elem_key);
            }
        }
        else
        {
            if(nodes[elem_key] < nodes[parent_key])
            {
                swap_nodes(parent_key,elem_key);
                bubble_up_min(parent_key);
            }
            else
            {
                bubble_up_max(elem_key);
            }
        }
    }
    return;
}
            

template <class T>
void minMaxHeap<T>::deleteMin()
{
    nodes[0] = nodes[nodes.size() - 1];
    nodes.pop_back();
    trickle_down(0);
    return;
}

template <class T>
void minMaxHeap<T>::deleteMax()
{
    if(nodes[1] < nodes[2])
    {
        nodes[2] = nodes[nodes.size() - 1];
        nodes.pop_back();
        trickle_down(2);
    }
    else
    {
        nodes[1] = nodes[nodes.size() - 1];
        nodes.pop_back();
        trickle_down(1);
    }
    return;
}

template <class T>
T minMaxHeap<T>::getMin()
{
    return nodes[0];
}

template <class T>
T minMaxHeap<T>::getMax()
{
    if(nodes[1] < nodes[2])
    {
        return nodes[2];
    }
    else
    {
        return nodes[1];
    }
}
