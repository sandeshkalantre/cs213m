Reference for list
http://www.cplusplus.com/reference/list/list/
