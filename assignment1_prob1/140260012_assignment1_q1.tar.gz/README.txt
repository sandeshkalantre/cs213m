Cycle Detection
http://www.wikiwand.com/en/Cycle_detection#/Tortoise_and_hare

